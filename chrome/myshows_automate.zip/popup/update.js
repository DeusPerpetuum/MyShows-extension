async function getVersions() {
	const manifest = chrome.runtime.getManifest();
	const updateElement = document.getElementById('update');
	updateElement.innerText = `v.${manifest.version}`
}

getVersions();
